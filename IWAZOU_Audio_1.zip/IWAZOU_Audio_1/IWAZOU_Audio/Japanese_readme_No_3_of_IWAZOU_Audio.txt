----------  Start Japanese_readme_No_3_of_IWAZOU_Audio.txt  ------------

Character Encoding is UTF-8 without BOM.

========================================================================
                Copyright (C) 2007-2026 [Iwazou Kondou]
========================================================================

[ English zone : start ]================================================

----- This file is written in "Developer Native Language"(Japanese) ----

############################# preface #############################

Permitted for [music or video or photo] use only.
Not permitted other than for [music or video or photo] use.

This programmer is 54 years old Japanese amateur./Ad 2026
19 years programming.
I am beginner of 19 years.
But I have this software Copyright.

This software,program work is fictional space use.

This software is original only.
Original is [Not use [copy/paste]].

If not like,please delete this software.
If exist complaint,please delete this software.
If exist problem,please delete this software.
If it is lawsuit,please delete this software.
If execute the higher power,please delete this software.

If use,regarded as agreement to everything.

No Forcing.
If exist your favorite version,please enjoy your favorite version.
###################################################################


###########[Settings] Written in English #############################

[Native Profile]******************************************************
=============================================================
Birthplace
[         Country          ] Japan
[        Prefecture        ] Tottori
------------------------------------------------------------
Language
[      Native Language     ] Japanese
=============================================================
age
[           age            ] 54 years old/Ad 2026
[          Birth           ] Ad 1972
------------------------------------------------------------
Did
[           Did            ] Photographic artist
------------------------------------------------------------
health
[         health 1         ] Ad 2003/7/7,cerebral hemorrhage
[         health 2         ] Continue "Person with higher brain dysfunction" from cerebral hemorrhage
[         health 3         ] Before cerebral hemorrhage, Novelist of photograph of 8x10 Large-format film camera.
------------------------------------------------------------
**********************************************************************

[System Common Setting]***********************************************
[      Common Encoding     ] UTF-8 without BOM
[  World Common Language   ] American English
[System programming parts 1] Programming Language is C++.
[System programming parts 2] C++ programming is written in "World Common Language".
[System programming parts 3] "World Common Language",Use "1 byte characters" with UTF-8 without BOM Encoding.
**********************************************************************

[This file Setting]***************************************************
[       File Encoding      ] UTF-8 without BOM
[Developer Native Language ] Japanese
[    Written Language 1    ] This file is written in "Developer Native Language".
[    Written Language 2    ] "Developer Native Language",Use ["1 byte characters" and "Multi-byte characters"] with UTF-8 without BOM Encoding.
**********************************************************************

###########[Settings] Written in English #############################

**********************************************************************
Below, Written in "Developer Native Language".
Use "Developer Native Language" with ["1 byte characters" and "Multi-byte characters"].
**********************************************************************
"Written in Japanese" with Use ["1 byte characters" and "Multi-byte characters"].

[ English zone : end ]==================================================

[ Japanese zone : start ]===============================================
Japanese begins here.

■■■■■■■■■■■■■　【序文 4】　■■■■■■■■■■■■■■

-------------------------------------------------

1ページ

第八作です

---------------------------　【序文 3】　---------------------------

後追い、貼り付け型よりも、
そもそも存在しない、「新規ページ」型
プログラミングを選んだ。

スタートは、何十年も遅れた。
だが、ロケットが創れると、「こっちは自作ロケットだ」

先行者の役割は性能ではない。
何も無い、0から創り上げることだ。

---------------------------　【序文 3】　---------------------------

19年開発。
私は、朝・昼・晩と、一生・死ぬまで薬を飲まなければならない。
この忍耐性が、プログラミング忍耐性になっているだろう。

アマチュアおじさんですよ。

-------------------------------------------------
2ページ

一応、性能書いておきますね

仮想メモリ　　281474976710656　TB(256RB) 15個
仮想バッファ　281474976710656　TB(256RB) 15個

架空CPU　 「周波数 1GHz/コア数 1core/深度 10384593717069655257060992658440192 bit(1024QB)」

架空電源　「電圧AC[50/60]Hz±100ボルト(日本国、一般家庭標準)/電流1億桁アンペア」

量子コンピュータなんてむつかしいことは、わかりません。
単純にbitを多くしただけです。

スーパーコンピューター富岳から、学習しました。「必要最小限」
予算は巨大に。使用は、必要最小限。
最小限は、8bit CPU(Intel 8080クラス)[パーソナルコンピューター黎明期]ですよ。
「解決できるだけの最小限」にレベルを上げ、解決していくというスタンスです。

尋常じゃないハイレベルでありながら、使用は最小限にまとめる。

富岳様、技術公開してくださって、ありがとうございました。

-------------------------------------------------
3ページ

一般人が、家庭用コンピュータで、
架空でスーパーコンピューターを持てたら、うれしいじゃないかということで。

先行者の役割は性能ではない。
何も無い、0から創り上げることだ。

-------------------------------------------------
4ページ

私のソフトウェアで、音楽を楽しんでくれれば、うれしいです。

-------------------------------------------------
5ページ

鉄棒、逆上がりもできなかった私だよ
跳び箱も跳べなかった私だよ

-------------------------------------------------

■■■■■■■■■■■■■　【序文 4】　■■■■■■■■■■■■■■

Japanese up to here.
[ Japanese zone : end ]=================================================

----------   End Japanese_readme_No_3_of_IWAZOU_Audio.txt   ------------